<?php
/**
 * @OA\Info(
 *     title="Chat App API",
 *     version="1.0.0",
 *     description="API documentation for the Chat App project",
 *     @OA\Contact(
 *         email="support@chatapp.com"
 *     )
 * )
 */
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ChatroomController;
use App\Http\Controllers\MessageController;

Route::post('login', [AuthController::class, 'login']);
Route::post('register', [AuthController::class, 'register']);


Route::post('chatrooms', [ChatroomController::class, 'store']);
Route::get('getchatrooms', [ChatroomController::class, 'index']);
Route::delete('chatrooms/{chatroom_id}/leave', [ChatroomController::class, 'leave']);
Route::post('chatrooms/{chatroom_id}/enter', [ChatroomController::class, 'enter']);
Route::post('chatrooms/{chatroom_id}/messages', [MessageController::class, 'store']);
Route::get('chatrooms/{chatroom_id}/messages', [MessageController::class, 'index']);


// Route::middleware(['auth:sanctum'])->group(function () {
//     Route::post('chatrooms', [ChatroomController::class, 'store']);
//     Route::get('chatrooms', [ChatroomController::class, 'index']);
// });
