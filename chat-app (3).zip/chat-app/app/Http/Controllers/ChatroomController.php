<?php

namespace App\Http\Controllers;

use App\Models\Chatroom;
use Illuminate\Http\Request;

    /**
     * @OA\Info(title="Chatroom API", version="1.0.0")
     */
    /**
     * @OA\Schema(
     *     schema="Chatroom",
     *     type="object",
     *     title="Chatroom",
     *     required={"id", "name"},
     *     @OA\Property(property="id", type="integer", description="Chatroom ID"),
     *     @OA\Property(property="name", type="string", description="Chatroom name"),
     *     @OA\Property(property="created_at", type="string", format="date-time", description="Creation timestamp"),
     *     @OA\Property(property="updated_at", type="string", format="date-time", description="Last update timestamp")
     * )
     */



class ChatroomController extends Controller
{
    /**
     * @OA\Post(
     *     path="/api/chatrooms",
     *     operationId="createChatroom",
     *     tags={"Chatrooms"},
     *     summary="Create a new chatroom",
     *     description="Creates a new chatroom and returns it",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="name", type="string", description="Name of the chatroom", example="General"),
     *             @OA\Property(property="description", type="string", nullable=true, description="Description of the chatroom", example="This is a general chatroom.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Chatroom created successfully",
     *         @OA\JsonContent(ref="#/components/schemas/Chatroom")
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Internal server error"
     *     )
     * )
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $chatroom = Chatroom::create($request->all());
        return response()->json($chatroom, 201);
    }

    public function index()
    {
        $chatrooms = Chatroom::all();
        return response()->json($chatrooms);
    }


    /**
     * @OA\Delete(
     *     path="/api/chatrooms/{chatroom_id}/leave",
     *     operationId="leaveChatroom",
     *     tags={"Chatrooms"},
     *     summary="Leave a chatroom",
     *     description="Allows the authenticated user to leave a specified chatroom.",
     *     @OA\Parameter(
     *         name="chatroom_id",
     *         in="path",
     *         required=true,
     *         description="ID of the chatroom the user wants to leave",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="User left the chatroom successfully",
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="message", type="string", example="You have left the chatroom.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Chatroom not found"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Internal server error"
     *     )
     * )
    */
    public function leave($chatroom_id)
    {
        $chatroom = Chatroom::findOrFail($chatroom_id);
        $userId = auth()->id() ?? 1; 
        $chatroom->users()->detach($userId);

        return response()->json(['message' => 'You have left the chatroom.']);
    }


    /**
     * @OA\Post(
     *     path="/api/chatrooms/{chatroom_id}/enter",
     *     operationId="enterChatroom",
     *     tags={"Chatrooms"},
     *     summary="Enter a chatroom",
     *     description="Allows the authenticated user to enter a specified chatroom.",
     *     @OA\Parameter(
     *         name="chatroom_id",
     *         in="path",
     *         required=true,
     *         description="ID of the chatroom the user wants to enter",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="User entered the chatroom successfully",
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="message", type="string", example="You have entered the chatroom.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Chatroom not found"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Internal server error"
     *     )
     * )
    */
    public function enter($chatroom_id)
    {
        $chatroom = Chatroom::findOrFail($chatroom_id);
        $userId = auth()->id() ?? 1; 
        $chatroom->users()->attach($userId);

        return response()->json(['message' => 'You have entered the chatroom.']);
    }

    

}
