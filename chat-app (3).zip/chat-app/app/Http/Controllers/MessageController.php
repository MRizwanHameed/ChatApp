<?php
namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;
    /**
     * @OA\Schema(
     *     schema="Message",
     *     type="object",
     *     title="Message",
     *     required={"id", "chatroom_id", "user_id", "type", "content"},
     *     @OA\Property(property="id", type="integer", description="Message ID"),
     *     @OA\Property(property="chatroom_id", type="integer", description="ID of the chatroom"),
     *     @OA\Property(property="user_id", type="integer", description="ID of the user who sent the message"),
     *     @OA\Property(property="type", type="string", enum={"text", "attachment"}, description="Type of the message"),
     *     @OA\Property(property="content", type="string", nullable=true, description="Content of the message"),
     *     @OA\Property(property="created_at", type="string", format="date-time", description="Creation timestamp"),
     *     @OA\Property(property="updated_at", type="string", format="date-time", description="Last update timestamp")
     * )
    */

class MessageController extends Controller
{
    /**
     * @OA\Post(
     *     path="/api/chatrooms/{chatroom_id}/messages",
     *     operationId="sendMessage",
     *     tags={"Messages"},
     *     summary="Send a message to a chatroom",
     *     description="Allows the authenticated user to send a text or attachment message to a specified chatroom.",
     *     @OA\Parameter(
     *         name="chatroom_id",
     *         in="path",
     *         required=true,
     *         description="ID of the chatroom",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             type="object",
     *             required={"type"},
     *             @OA\Property(property="type", type="string", enum={"text", "attachment"}, description="Type of the message (text or attachment)", example="text"),
     *             @OA\Property(property="content", type="string", nullable=true, description="Content of the message if type is 'text'", example="Hello world")
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Message sent successfully",
     *         @OA\JsonContent(ref="#/components/schemas/Message")
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Internal server error"
     *     )
     * )
    */
    public function store(Request $request, $chatroom_id)
    {
        $request->validate([
            'type' => 'required|string|in:text,attachment',
            'content' => 'required_if:type,text|string',
        ]);

        $message = new Message();
        $message->chatroom_id = $chatroom_id;
        $message->user_id = auth()->id() ?? 1; // Update with authenticated user ID
        $message->type = $request->type;
        $message->content = $request->content;

        $message->save();

        return response()->json($message, 201);
    }



    /**
     * @OA\Get(
     *     path="/api/chatrooms/{chatroom_id}/messages",
     *     operationId="getChatroomMessages",
     *     tags={"Messages"},
     *     summary="Get messages in a chatroom",
     *     description="Retrieves all messages from a specified chatroom.",
     *     @OA\Parameter(
     *         name="chatroom_id",
     *         in="path",
     *         required=true,
     *         description="ID of the chatroom to retrieve messages from",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation",
     *         @OA\JsonContent(
     *             type="array",
     *             @OA\Items(ref="#/components/schemas/Message")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Chatroom not found"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Internal server error"
     *     )
     * )
    */
    public function index($chatroom_id)
    {
        $messages = Message::where('chatroom_id', $chatroom_id)->get();
        return response()->json($messages);
    }

}
